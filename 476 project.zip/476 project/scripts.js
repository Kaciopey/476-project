function startQuiz() {
    const quizDiv = document.getElementById('quiz');
    quizDiv.innerHTML = `
        <p>Who won the 2009 Super Bowl?</p>
        <button onclick="answer('correct')">Steelers</button>
        <button onclick="answer('wrong')">Cardinals</button>
    `;
}

function answer(response) {
    const quizDiv = document.getElementById('quiz');
    if (response === 'correct') {
        quizDiv.innerHTML = '<p>Correct! The Steelers won Super Bowl XLIII.</p>';
    } else {
        quizDiv.innerHTML = '<p>Incorrect. Try again!</p>';
    }
}
